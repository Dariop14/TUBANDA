<!-- Se define como cerrar la ventana modal -->
<a href="javascript:cerrarReserva();">cerrar</a><br>

<?php
    // Se imprime un mensaje instructivo con el nombre del usuario
    echo  $_SESSION['uUsuario'];  ?> , Seleciona la fecha y banda que desees reservar:
    <!-- Se establece los campos de nombre de banda y fecha de reserva -->
    <form method="post">
     <input type="text" name="nombreBanda" placeholder="Banda o músico">
     <input type="date" name="fechaReserva" placeholder="YYYY-MM-DD">
     </br>
     </br>
     <input class="submit" type="submit" name="reservarFecha"  value="Reservar"/>
    </form>

<?php
// Se comprueba que se aplasto el botón de reservar
if(isset($_POST['reservarFecha'])){
  // Se define variables que lean los datos ingresados
  $perNombre = mysql_real_escape_string($_POST['nombreBanda']);
  $rFecha = mysql_real_escape_string($_POST['fechaReserva']);

   // Se realiza una consulta para extraer el ID del usuario actual
   $usuario_usuario = $_SESSION['uUsuario'];
   $uID = mysql_query("SELECT uID FROM Usuario WHERE uUsuario = '$usuario_usuario'");
   if($row = mysql_fetch_array($uID)){
     $id_usuario = $row[0];
    // Se realiza una consulta para extraer el nombre de banda o músico seleccionado
   $perfilNombre = mysql_query("SELECT pNombre FROM Perfil WHERE pNombre = '$perNombre' ");
   if($row = mysql_fetch_array($perfilNombre)){
     $nPerfil = $row[0];
   }
   // Se comprueba que no este vacía la fecha ni el nombre
     if(empty($_POST['fechaReserva'])){
         echo "Debes seleccionar la fecha a reservar. <a href='javascript:history.back();'>Reintentar</a>";
     } else if(empty($_POST['nombreBanda'])){
         echo "Debes ingresar el nombre de la banda a reservar. <a href='javascript:history.back();'>Reintentar</a>";
     }else {
       // Si los campos están llenos se procede a comprobar si la fecha para esa banda está disponible
       $sql = mysql_query("SELECT * FROM Reservas WHERE pNombre='".$nPerfil."' AND rFecha = '".$rFecha."'");
       if(mysql_num_rows($sql) > 0) {
          // Mensaje si la fecha no está disponible
           echo "Esta fecha no está disponible.";
       }else {
        // Si la fecha está disponible, ingresar los datos de reserva a la BD
       $ingresarFecha = mysql_query("INSERT INTO Reservas (uID,pNombre,rFecha)
               VALUES ('".$id_usuario."','".$nPerfil."','".$rFecha."')");

        // Si la reserva fue exitosa, imprimir esto
         if ($ingresarFecha) {
           echo "Reserva realizada<br><br>";
           echo "Seguir Buscando en <a href='artistas.php'>Musicos</a><br>";
           echo "Seguir Buscando en <a href='bandas.php'>Bandas</a><br>";
           echo "Ver mis reservas <a href='perfil.php'>Contratos</a>";
        } else {
          // Caso contrario se imprime lo siguiente
         echo "Reserva fallida";
        }
      }

  }
}
}

?>
