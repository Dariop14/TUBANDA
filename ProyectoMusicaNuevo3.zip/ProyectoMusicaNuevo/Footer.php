<!-- Se agregan los enlaces a redes sociales -->
<div class="container-redes">
    <p style="padding: 0px;">
      <a href="#"><img class="redes" src="redesSociales/FBv.svg" alt="Facebook LOGO"></a>
      <a href="#"><img class="redes" src="redesSociales/instagram.svg" alt="instagram LOGO"></a>
      <a href="#"><img class="redes" src="redesSociales/twitter.svg" alt="twitter LOGO"></a>
      <a href="#"><img class="redes" src="redesSociales/soundcloud.svg" alt="soundcloud LOGO"></a>
    </p>
</div>

      <!-- Se agrega el logo y copyright de la página -->
      <div class="container-TuBanda">

          <div class="logo" style="margin-left: 100px;"><a  href="index.php">Tu Banda</a></div>
          <br>

          <p style="color:#d8e2dc; font-size: 14px; margin-left: 28%;">
            Todos los derechos y Copyright reservados <br/>
          <br>
            TuBanda 2017
          </p>
      </div>

    <!-- Se agrega la sección de contactanos -->
    <div class="container-contactanos">
      <p style="color:#d8e2dc; font-size: 15px;">
          Contactanos <br/><br>
        0972876564 | 0978765735 <br/>
        consultas@tubanda.com.ec <br/>
        servicioalcliente@tubanda.com.ec
      </p>
    </div>
