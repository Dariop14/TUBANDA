<!-- Selector con opciones de Genero -->
<select name="genero" style="width:60%; margin-top:0px;height: 40px;">
<option value="Rock">Rock</option>
<option value="Reggae">Reggae</option>
<option value="Pop">Pop</option>
<option value="Jazz">Jazz</option>
<option value="Indie">Indie</option>
</select>
