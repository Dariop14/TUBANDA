

     <?php
       // Se consulta a la BD los elementos que correspondan a bandas y se obtiene sus datos
         if($Resultado = mysql_query("SELECT * FROM Perfil WHERE pGenero = 'Rock'")){
             while($Fila = mysql_fetch_assoc($Resultado)){
               $pfoto = $Fila["pImagen"];
               $pnombre = $Fila["pNombre"];
               $pgenero = $Fila["pGenero"];
               $pdescripcion = $Fila["pDescripcion"];

               echo "<div class='contenedor-artistas noColapsar'>";
               echo "<p class='contenedor-artista-individual noColapsar' style='padding-top=20px;'>";
               // Se establece como se desea imprimir la información de cada banda
               $printResultados = "<img class='contenedor-imagen-artistas' src='$pfoto' width='220' height='220'><br>";
               $printResultados.= "<a href='perfilCompleto.php' style='text-decoration:none; color:black;'><strong>$pnombre</strong></a>";
               $printResultados.= "<br><br>$pgenero<br><br>";
               $printResultados.= "$pdescripcion";
               $printResultados.= "<br><br><a class='reservarbtn' href='javascript:Reserva();'>Reservar</a>";
               // Se imprime el resultado
               echo "$printResultados";

               echo "</p>";
               echo "</div>";
             }
         }
      ?>

      <?php
        // Se consulta a la BD los elementos que correspondan a bandas y se obtiene sus datos
          if($Resultado = mysql_query("SELECT * FROM Perfil WHERE pGenero = 'Reggae'")){
              while($Fila = mysql_fetch_assoc($Resultado)){
                $pfoto = $Fila["pImagen"];
                $pnombre = $Fila["pNombre"];
                $pgenero = $Fila["pGenero"];
                $pdescripcion = $Fila["pDescripcion"];

                echo "<div class='contenedor-artistas noColapsar'>";
                echo "<p class='contenedor-artista-individual noColapsar' style='padding-top=20px;'>";
                // Se establece como se desea imprimir la información de cada banda
                $printResultados = "<img class='contenedor-imagen-artistas' src='$pfoto' width='220' height='220'><br>";
                $printResultados.= "<a href='perfilCompleto.php' style='text-decoration:none; color:black;'><strong>$pnombre</strong></a>";
                $printResultados.= "<br><br>$pgenero<br><br>";
                $printResultados.= "$pdescripcion";
                $printResultados.= "<br><br><a class='reservarbtn' href='javascript:Reserva();'>Reservar</a>";
                // Se imprime el resultado
                echo "$printResultados";

                echo "</p>";
                echo "</div>";
              }
          }
       ?>

             <?php
               // Se consulta a la BD los elementos que correspondan a bandas y se obtiene sus datos
                 if($Resultado = mysql_query("SELECT * FROM Perfil WHERE pGenero = 'Pop'")){
                     while($Fila = mysql_fetch_assoc($Resultado)){
                       $pfoto = $Fila["pImagen"];
                       $pnombre = $Fila["pNombre"];
                       $pgenero = $Fila["pGenero"];
                       $pdescripcion = $Fila["pDescripcion"];

                       echo "<div class='contenedor-artistas noColapsar'>";
                       echo "<p class='contenedor-artista-individual noColapsar' style='padding-top=20px;'>";
                       // Se establece como se desea imprimir la información de cada banda
                       $printResultados = "<img class='contenedor-imagen-artistas' src='$pfoto' width='220' height='220'><br>";
                       $printResultados.= "<a href='perfilCompleto.php' style='text-decoration:none; color:black;'><strong>$pnombre</strong></a>";
                       $printResultados.= "<br><br>$pgenero<br><br>";
                       $printResultados.= "$pdescripcion";
                       $printResultados.= "<br><br><a class='reservarbtn' href='javascript:Reserva();'>Reservar</a>";
                       // Se imprime el resultado
                       echo "$printResultados";

                       echo "</p>";
                       echo "</div>";
                     }
                 }
              ?>

              <?php
                // Se consulta a la BD los elementos que correspondan a bandas y se obtiene sus datos
                  if($Resultado = mysql_query("SELECT * FROM Perfil WHERE pGenero = 'Indie'")){
                      while($Fila = mysql_fetch_assoc($Resultado)){
                        $pfoto = $Fila["pImagen"];
                        $pnombre = $Fila["pNombre"];
                        $pgenero = $Fila["pGenero"];
                        $pdescripcion = $Fila["pDescripcion"];

                        echo "<div class='contenedor-artistas noColapsar'>";
                        echo "<p class='contenedor-artista-individual noColapsar' style='padding-top=20px;'>";
                        // Se establece como se desea imprimir la información de cada banda
                        $printResultados = "<img class='contenedor-imagen-artistas' src='$pfoto' width='220' height='220'><br>";
                        $printResultados.= "<a href='perfilCompleto.php' style='text-decoration:none; color:black;'><strong>$pnombre</strong></a>";
                        $printResultados.= "<br><br>$pgenero<br><br>";
                        $printResultados.= "$pdescripcion";
                        $printResultados.= "<br><br><a class='reservarbtn' href='javascript:Reserva();'>Reservar</a>";
                        // Se imprime el resultado
                        echo "$printResultados";

                        echo "</p>";
                        echo "</div>";
                      }
                  }
               ?>
               <?php
                 // Se consulta a la BD los elementos que correspondan a bandas y se obtiene sus datos
                   if($Resultado = mysql_query("SELECT * FROM Perfil WHERE pGenero = 'Jazz'")){
                       while($Fila = mysql_fetch_assoc($Resultado)){
                         $pfoto = $Fila["pImagen"];
                         $pnombre = $Fila["pNombre"];
                         $pgenero = $Fila["pGenero"];
                         $pdescripcion = $Fila["pDescripcion"];

                         echo "<div class='contenedor-artistas noColapsar'>";
                         echo "<p class='contenedor-artista-individual noColapsar' style='padding-top=20px;'>";
                         // Se establece como se desea imprimir la información de cada banda
                         $printResultados = "<img class='contenedor-imagen-artistas' src='$pfoto' width='220' height='220'><br>";
                         $printResultados.= "<a href='perfilCompleto.php' style='text-decoration:none; color:black;'><strong>$pnombre</strong></a>";
                         $printResultados.= "<br><br>$pgenero<br><br>";
                         $printResultados.= "$pdescripcion";
                         $printResultados.= "<br><br><a class='reservarbtn' href='javascript:Reserva();'>Reservar</a>";
                         // Se imprime el resultado
                         echo "$printResultados";

                         echo "</p>";
                         echo "</div>";
                       }
                   }
                ?>
