<html lang="es">

<head>
<meta charset="utf-8" />
<title>Músicos</title>
<link rel="stylesheet" href="css/masterEstilos.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript">
            function desplegar(){
                document.getElementById("InicioSesion").style.display="block";
            }

            function cerrar(){
                document.getElementById("InicioSesion").style.display="none";
            }

            function desplegarRegistro(){
                document.getElementById("registro").style.display="block";
            }

            function cerrarRegistro(){
                document.getElementById("registro").style.display="none";
            }

            function Reserva(){
              document.getElementById("reserva").style.display="block";
            }

            function cerrarReserva(){
              document.getElementById("reserva").style.display="none";
            }

            function MenuResponsive()
            {
              var x = document.getElementById("BarraResponsive");
               if (x.className === "menu") {
                   x.className += " responsive";
               } else {
                   x.className = "menu";
               }
             }


            $(document).ready(function(){
            $("#flip-Genero").click(function(){
            $("#panel-Genero").slideToggle("slow");
              });
            });

            $(document).ready(function(){
            $("#flip-Instrumentos").click(function(){
            $("#panel-Instrumentos").slideToggle("slow");
              });
            });

  </script>

</head>
<body>
<!-- Incluímos el header con su menú  -->
<?php  include("Header.php");  ?>
<?php  include("menu.php");  ?>

<!-- Agregamos los filtros -->
</nav>
<section class="contenedor-filtros-master">
<div class="contenedor-filtros clear">
<div id="flip-Instrumentos">Instrumentos</div>
<div id="panel-Instrumentos">
  <br/>
  <a class="contenedor-items-filtros" href="guitarra.php">
 Guitarra
  </a>
  <a class="contenedor-items-filtros" href="bateria.php">
  Bateria
  </a>
  <a class="contenedor-items-filtros" href="bajo.php">
 Bajo
  </a>
  <a class="contenedor-items-filtros" ref="saxophone.php">
 Saxophone
  </a>
  <a class="contenedor-items-filtros" ref="teclado.php">
 Teclado
</div>
</div>

<div class="contenedor-filtros clear">
  <p style="margin:0px;" id="flip-Genero">Generos</p>
  <div id="panel-Genero">
    <br/>
  <a class="contenedor-items-filtros" href="reggae.php">
 Reggae
  </a>
<a class="contenedor-items-filtros"  href="jazz.php">
  Jazz
  </a>
  <a class="contenedor-items-filtros" href="rock.php">
 Rock
  </a>
  <a class="contenedor-items-filtros" href="indie.php">
 Indie
  </a>
  <a class="contenedor-items-filtros" href="pop.php">
 Pop
  </a>
</div>
</div>
</section>
<br>

<section>
<!-- Inlcuimos un menú de reserva en forma de ventana modal cuando presionemos el boton reservar -->
  <div id='reserva'>
      <?php include("ReservarFecha.php"); ?>
  </div>

</section>
</body>
