<?php session_start(); ?>
<p>
  <?php echo  $_SESSION['uUsuario'];  ?> , Seleciona la fecha tentativa que desees reservar
</p>
     <form method="post" action="perfil.php">
      <input type="date" name="fechaReserva">
      </br>
      </br>
      <input class="reservarbtn" type="submit" name="reservarFecha"  value="Reservar"/>
     </form>

 <?php

if(isset($_POST['reservarFecha'])){
   // Se realiza una consulta para extraer el ID del usuario actual
   $usuario_usuario = $_SESSION['uUsuario'];
   $uID = mysql_query("SELECT uID FROM Usuario WHERE uUsuario = '$usuario_usuario'");
   if($row = mysql_fetch_array($uID)){
     $id_usuario = $row[0];
  }

   if(isset($_POST['reservarFecha'])){

      $perfilConstratado = mysql_real_escape_string($_POST['pID']);
      $rFecha = mysql_real_escape_string($_POST['rFecha']);

      if(empty($_POST['rFecha'])){
          echo "Debes seleccionar la fecha a reservar. <a href='javascript:history.back();'>Reintentar</a>";
      }else {
        $ingresarFecha = mysql_query("INSERT INTO Reservas (uID,pID,rFecha)
                VALUES ('".$id_usuario."','".$perfilConstratado."','".$rFecha."')");


      if ($ingresarFecha) {
      echo "Reserva realizada";
      echo "Seguir Buscando en <a href='artistas.php'>Musicos</a>";
      echo "Seguir Buscando en <a href='bandas.php'>Bandas</a>";
      echo "Ver mis reservas <a href='perfil.php'>Musicos</a>";
    }
   }
  }
}
  ?>
