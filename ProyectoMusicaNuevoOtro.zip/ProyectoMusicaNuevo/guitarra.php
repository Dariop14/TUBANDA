<?php
 include("filtros.php");
 // Se consulta a la BD los elementos(instrumento) que correspondan a musico y se obtiene sus datos
    if($Resultado = mysql_query("SELECT * FROM Perfil WHERE pInstrumento = 'Guitarra' and pTipo ='musico'")){
        while($Fila = mysql_fetch_assoc($Resultado)){
          $pfoto = $Fila["pImagen"];
          $pnombre = $Fila["pNombre"];
          $pinstrumento = $Fila["pInstrumento"];
          $pgenero = $Fila["pGenero"];
          $pdescripcion = $Fila["pDescripcion"];

          echo "<div class='contenedor-artistas noColapsar'>";
          echo "<p class='contenedor-artista-individual noColapsar' style='padding-top=20px;'>";
          // Se establece como se desea imprimir la información de cada musico que toca el trader_cdlabandonedbaby
          $printResultados = "<img class='contenedor-imagen-artistas' src='$pfoto' width='220' height='220'><br>";
          $printResultados.= "<a href='perfilCompleto.php' style='text-decoration:none; color:black;'><strong>$pnombre</strong></a>";
          $printResultados.= "</br></br><b>Genero:</b> $pgenero<br><b>Instrumento:</b>$pinstrumento<br>";
          $printResultados.= "</br><b>Descripcion de la banda/musico:</b></br>$pdescripcion";
          $printResultados.= "<a class='reservarbtn' href='javascript:Reserva();'>Reservar</a>";
// Se imprime el resultado
          echo "$printResultados";

          echo "</p>";
          echo "</div>";
        }
    }

    ?>

    <footer>
       <!-- Se imprime el footer común -->
          <?php  include("Footer.php"); ?>
    </footer>
