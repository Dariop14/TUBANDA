<?php
    // Extraemos el ID del usuario actual
    $usuario_usuario = $_SESSION['uUsuario'];
    $uID = mysql_query("SELECT uID FROM Usuario WHERE uUsuario = '$usuario_usuario'");
    if($row = mysql_fetch_array($uID)){
      $id_usuario = $row[0];
    }
 ?>

<?php
    // Preguntamos si el usuario actual cuenta con perfiles asociados a su ID
    $existente = mysql_query("SELECT * FROM Perfil WHERE uID = '$id_usuario'");
    if(mysql_num_rows($existente) > 0){
 ?>

<div class="foto">

    <?php
        // De haber perfiles existentes se extrae la información del perfil
        $fotoPerfil = mysql_query("SELECT pImagen FROM Perfil WHERE uID = '$id_usuario'");
        if($row = mysql_fetch_array($fotoPerfil)){
          $img = $row[0];
        }

        echo "<img src='$img' width='160' height='180'>";
     ?>

</div>

<div class="Datos">

  <?php
      echo "<p><a href='musico.php'>";
      $bandaNombre = mysql_query("SELECT pNombre FROM Perfil WHERE uID = '$id_usuario'");
      if($row = mysql_fetch_array($bandaNombre)){
        echo $row[0];
      }
      echo "</a></p>";

      echo "<p>";
      $bandaGenero = mysql_query("SELECT pGenero FROM Perfil WHERE uID = '$id_usuario'");
      if($row = mysql_fetch_array($bandaGenero)){
        echo $row[0];
      }
      echo "</p>";

      echo "<p>";
      $bandaDescripcion = mysql_query("SELECT pDescripcion FROM Perfil WHERE uID = '$id_usuario'");
      if($row = mysql_fetch_array($bandaDescripcion)){
        echo $row[0];
      }
      echo "</p>";
  ?>

</div>

<?php
 } else {
 ?>
 <!--  De no existir ningún perfil asociado se lo notifica  -->
 <p>No cuentas con perfiles publicados al momento</p>

<?php } ?>
