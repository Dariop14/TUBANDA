    <?php

    include('filtros.php');
    // Se realiza una consulta a la BD pidiendo los elementos que sean músicos
        if($Resultado = mysql_query("SELECT * FROM Perfil WHERE pTipo = 'musico'")){
            while($Fila = mysql_fetch_assoc($Resultado)){
              // Obtenemos los datos de cada elemento del perfil seleccionado
              $pfoto = $Fila["pImagen"];
              $pnombre = $Fila["pNombre"];
              $pgenero = $Fila["pGenero"];
              $pinstrumento = $Fila["pInstrumento"];
              $pdescripcion = $Fila["pDescripcion"];

              // Establecemos los contenedores de cada tableta de perfil
              echo "<div class='contenedor-artistas noColapsar'>";
              echo "<p class='contenedor-artista-individual noColapsar' style='padding-top=20px;'>";

              // Establecemos lo que deseamos imprimir
              $printResultados = "<img class='contenedor-imagen-artistas' src='$pfoto' width='220' height='220'><br>";
              $printResultados.= "<a href='perfilCompleto.php' style='text-decoration:none; color:black;'><strong>$pnombre</strong></a>";
              $printResultados.= "</br></br><b>Genero:</b> $pgenero<br><b>Instrumento:</b>$pinstrumento<br>";
              $printResultados.= "</br><b>Descripcion de la banda/musico:</b></br>$pdescripcion";
              $printResultados.= "<a class='reservarbtn' href='javascript:Reserva();'>Reservar</a>";

              // Se imprimen los resultados
              echo "$printResultados";

              echo "</p>";
              echo "</div>";
            }
        }
     ?>

</section>
</body>

<footer>
   <!-- Se imprime el footer común -->
      <?php  include("Footer.php"); ?>
</footer>
