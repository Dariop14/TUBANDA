
<?php
  // Se realiza una consulta para extraer el ID del usuario actual
  $usuario_usuario = $_SESSION['uUsuario'];
  $uID = mysql_query("SELECT uID FROM Usuario WHERE uUsuario = '$usuario_usuario'");
  if($row = mysql_fetch_array($uID)){
    $id_usuario = $row[0];
  }
 ?>


<?php
// Se comprueba que existan reservas asociadas al usuario actual
$existente = mysql_query("SELECT * FROM Reservas WHERE uID = '$id_usuario'");
if(mysql_num_rows($existente) > 0){
  // Se existir reservas se procede a seleccionar todas ellas
  if($Resultado = mysql_query("SELECT * FROM Reservas WHERE uID = '$id_usuario'")){
      while($Fila = mysql_fetch_assoc($Resultado)){
        // Se extrae los datos de la reserva
        $pNombre = $Fila["pNombre"];
        $rFecha = $Fila["rFecha"];
        // Se establece lo que se desea imprimir en cada reserva
        $printResultados = $_SESSION['uUsuario'];
        $printResultados.= ", contrataste con éxito a: ";
        $printResultados.= "<strong>";
        $printResultados.= $pNombre;
        $printResultados.= "</strong><br>";
        $printResultados.= "para la fecha: <strong>";
        $printResultados.= $rFecha;
        $printResultados.= "</strong><br><br>";
        // Se imprime los resultados
        echo "$printResultados";
      }
      }
  } else {
    // Si no existen reservas asociadas al usuario, se lo notifica
    echo "No has reservado ningún músico o banda hasta el momento.";
  }

?>
