<?php
  include("acceso_db.php"); //conectamos DB
  ?>
<html>
<head>
    <title>Busqueda</title>
    <link rel="stylesheet" type="text/css" href="css/masterEstilos.css"/>
</head>
<body>
<?php
include("header.php");
include("menu.php");
    $query = $_POST['query']; // llamamos los datos  guardados en el value query
    $min_length = 3; // establecemos un minimo de caracteres para buscqueda

    if(strlen($query) >= $min_length){ // realizar, si este es mayor o menor

        $query = htmlspecialchars($query); //cambiasmos caracteres especiales  guardados en html
        $query = mysql_real_escape_string($query);//liberamos el query
        $raw_results = mysql_query("SELECT * FROM Perfil
            WHERE (`pNombre` LIKE '%".$query."%') OR (`pDescripcion` LIKE '%".$query."%')") or die(mysql_error());
        // buscamos informacion parecida en la columna de pnombre y pdescripcion de Perfil
        //si coiciden con  '%$query%' *(datos ingresados por el usuario en el buscador)
        // '% variable %' sirve para buscar similitudes y relaciones, o sea,
        // no debe ser la palabra exacta para mandar la informacion
        if(mysql_num_rows($raw_results) > 0){ // si los resultados de la lista son mas de 0
            while($results = mysql_fetch_array($raw_results)){
            // imprimir datos en lista, recibidos de  DB
            $pfoto = $results["pImagen"];
            $pnombre = $results["pNombre"];
            $pInstrumento = $results["pInstrumento"];
            $pgenero = $results["pGenero"];
            $pdescripcion = $results["pDescripcion"];

            echo "<div class='contenedor-artistas noColapsar'>";
            echo "<p class='contenedor-artista-individual noColapsar' style='padding-top=20px;'>";
            // Se establece como se desea imprimir la información de cada banda
            $printResultados = "<img class='contenedor-imagen-artistas' src='$pfoto' width='220' height='220'><br>";
            $printResultados.= "<a href='perfilCompleto.php' style='text-decoration:none; color:black;'><strong>$pnombre</strong></a>";
            $printResultados.= "<br><br><b>Instrumeto:</b>$pInstrumento";
            $printResultados.= "<br><br><b>Genero:</b>$pgenero<br><br>";
            $printResultados.= "<b>Descripcion del artista/banda:</b></br>$pdescripcion";
            $printResultados.= "<br><br><a class='reservarbtn' href='javascript:Reserva();'>Reservar</a>";
            // Se imprime el resultado
            echo "$printResultados";

            echo "</p>";
            echo "</div>";
          }
          }else{ // si no coincide con ninguna informacion
            echo "No existen resultados  similares, por favor busca algo más";
        }
    }
    else{?>
        <div style="color:white; font-size: 15px; margin:40px;">
          <?php  // si lo tipiado es menor a lo establecido, imprimir informacion indicativa
        echo " Por favor, escribe más. ".$min_length;
        echo " letras no son suficientes para entontrar datos";
        ?>
      </div>
  <?php } ?>
</body>

<footer>
  <?php include("footer.php"); ?>
</footer>
</html>
