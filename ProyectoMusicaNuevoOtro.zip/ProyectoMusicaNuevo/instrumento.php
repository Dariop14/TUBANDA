<!-- Selector con opciones de instrumentos-->
<select name="instrumento" style="width:60%; margin-top:0px;height: 40px;">
<option value="Guitarra">Guitarra</option>
<option value="Bajo">Bajo</option>
<option value="Bateria">Bateria</option>
<option value="Teclado">Teclado</option>
<option value="Saxophone">Saxophone</option>
<option value="Varios">Varios</option>
</select>
