<?php
  // Obtenemos los datos del formulario para cambiar los datos del usuario
        $pNombre = mysql_real_escape_string($_POST['pNombre']);
        $pPais = mysql_real_escape_string($_POST['pPais']);
        $pContrasena = mysql_real_escape_string($_POST['pContrasena']);
        $usuarioImagen = mysql_real_escape_string($_FILES['uImagen']['name']);
        $uImagen_tmp = mysql_real_escape_string($_FILES['uImagen']['tmp_name']);
  // Chequeamos si los campos están llenos
        if(empty($_POST['pNombre'])){
            echo "No has escrito un nombre. <a href='javascript:history.back();'>Reintentar</a>";
        } else if (empty($_POST['pPais'])){
            echo "No has escrito tu país. <a href='javascript:history.back();'>Reintentar</a>";
        } else if (empty($_POST['pContrasena'])){
           echo "No has escrito tu contraseña. <a href='javascript:history.back();'>Reintentar</a>";
        } else {
   // Movemos la imagen subida hacia una carpeta de proyecto para leerla despues
            move_uploaded_file($_FILES['uImagen']['tmp_name'],"imagenesUsuario/".$_FILES['uImagen']['name']);
   // Actualizamos la información del usuario
            $actNombre = mysql_query("UPDATE Usuario SET uNombre ='".$pNombre."' WHERE uID ='".$id_usuario."'  ");
            $actPais = mysql_query("UPDATE Usuario SET uLugarOrigen ='".$pPais."' WHERE uID ='".$id_usuario."'  ");
            $actContrasena = mysql_query("UPDATE Usuario SET uContrasena ='".$pContrasena."' WHERE uID ='".$id_usuario."'  ");
            $actImagen = mysql_query("UPDATE Usuario SET uImagen ='imagenesUsuario/".$usuarioImagen."' WHERE uID = '".$id_usuario."' ");
          }

    ?>
