
<?php
  // Se realiza una consulta para extraer el ID del usuario actual
  $usuario_usuario = $_SESSION['uUsuario'];
  $uID = mysql_query("SELECT uID FROM Usuario WHERE uUsuario = '$usuario_usuario'");
  if($row = mysql_fetch_array($uID)){
    $id_usuario = $row[0];
  }
 ?>

<div id="Eventos">

<!--Extraemos de la BD las reservas registrada-->
  <p><?php  echo $_SESSION[uUsuario]; ?>, reservaste</p>
  <?php
//evento

   ?>
  <p>
    para esta fecha:
  </p>
<?php
$ReservasReg = mysql_query("SELECT rFecha FROM Reservas WHERE uID = '$id_usuario'");
if($row = mysql_fetch_array($ReservasReg)){
  echo $row[0];
  $rFecha = $row[0];
}
  ?>

</div>
